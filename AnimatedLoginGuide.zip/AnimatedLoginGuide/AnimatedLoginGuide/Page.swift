//
//  Page.swift
//  AnimatedLoginGuide
//
//  Created by Anas Al-khateeb on 11/1/18.
//  Copyright © 2018 Anas Al-khateeb. All rights reserved.
//

import Foundation

struct Page {
    let title: String
    let body: String
}
