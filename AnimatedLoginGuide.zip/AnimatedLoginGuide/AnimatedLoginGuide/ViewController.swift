//
//  ViewController.swift
//  AnimatedLoginGuide
//
//  Created by Anas Al-khateeb on 11/1/18.
//  Copyright © 2018 Anas Al-khateeb. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

